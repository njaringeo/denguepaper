"""
Add district names to each hotspot shapefile.

Expected repository layout:
  code_data/
    input_data/
      CaseHotspot/
      District_shp/
    scripts/

Outputs are written to:
  CaseHotspot_output/
"""

from pathlib import Path
import shutil

import shapefile


PROJECT_DIR = Path(__file__).resolve().parents[2]
INPUT_DIR = Path(__file__).resolve().parents[1] / "input_data"
DISTRICT_PATH = INPUT_DIR / "District_shp" / "district.shp"
HOTSPOT_DIR = INPUT_DIR / "CaseHotspot"
OUTPUT_DIR = PROJECT_DIR / "CaseHotspot_output"


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    district_reader = shapefile.Reader(str(DISTRICT_PATH), encoding="utf-8")
    district_names = [
        str(record.as_dict()["District"]).strip()
        for record in district_reader.records()
    ]

    written = []
    for shp_path in sorted(HOTSPOT_DIR.glob("*.shp")):
        reader = shapefile.Reader(str(shp_path), encoding="utf-8")
        if len(reader) != len(district_names):
            raise ValueError(
                f"{shp_path.name}: hotspot records ({len(reader)}) do not match "
                f"district records ({len(district_names)})"
            )

        out_base = OUTPUT_DIR / shp_path.stem
        writer = shapefile.Writer(
            str(out_base),
            shapeType=reader.shapeType,
            encoding="utf-8",
        )
        writer.autoBalance = 1

        existing_fields = reader.fields[1:]
        existing_names = [field[0].lower() for field in existing_fields]
        for field in existing_fields:
            writer.field(*field)
        if "district" not in existing_names:
            writer.field("district", "C", size=100)

        for shape_record, district_name in zip(reader.iterShapeRecords(), district_names):
            writer.shape(shape_record.shape)
            values = list(shape_record.record)
            if "district" in existing_names:
                values[existing_names.index("district")] = district_name
            else:
                values.append(district_name)
            writer.record(*values)
        writer.close()

        for ext in (".prj", ".PRJ", ".cpg", ".CPG"):
            sidecar = shp_path.with_suffix(ext)
            if sidecar.exists():
                shutil.copy2(sidecar, out_base.with_suffix(sidecar.suffix))

        written.append(shp_path.name)

    print(f"Wrote {len(written)} shapefiles to {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
