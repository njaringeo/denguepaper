"""
Generate binary hotspot matrices and same-season Jaccard Similarity Index outputs.

Run after 01_add_district_field_to_hotspots.py, or provide hotspot shapefiles that
already contain a district field.

Hotspot rule:
  Gi_Bin > 0 is coded as 1; Gi_Bin <= 0 is coded as 0.
"""

from pathlib import Path
import re

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import shapefile


PROJECT_DIR = Path(__file__).resolve().parents[2]
INPUT_HOTSPOT_DIR = PROJECT_DIR / "CaseHotspot_output"
OUTPUT_DIR = PROJECT_DIR / "Jaccard_results"

SEASON_INFO = {
    "Winter": {"label": "Winter", "abbr": "Win", "order": 1},
    "Premonsoon": {"label": "Pre-monsoon", "abbr": "PreM", "order": 2},
    "Monsoon": {"label": "Monsoon", "abbr": "Mon", "order": 3},
    "POMO": {"label": "Post-monsoon", "abbr": "PostM", "order": 4},
}


def parse_name(name: str) -> tuple[int, str, str, str, int]:
    match = re.match(r"CaseHotspot_(\d{4})(Winter|Premonsoon|Monsoon|POMO)\.shp$", name, re.I)
    if not match:
        raise ValueError(f"Unexpected shapefile name: {name}")

    year = int(match.group(1))
    season_key = match.group(2)
    for known in SEASON_INFO:
        if known.lower() == season_key.lower():
            season_key = known
            break

    info = SEASON_INFO[season_key]
    return year, season_key, info["label"], info["abbr"], info["order"]


def load_layers() -> tuple[list[dict], list[str]]:
    layers = []
    all_districts = None

    for shp_path in sorted(INPUT_HOTSPOT_DIR.glob("CaseHotspot_*.shp")):
        year, season_key, season_label, abbr, season_order = parse_name(shp_path.name)
        reader = shapefile.Reader(str(shp_path), encoding="utf-8")
        fields = [field[0] for field in reader.fields[1:]]
        lower_fields = [field.lower() for field in fields]
        if "gi_bin" not in lower_fields or "district" not in lower_fields:
            raise ValueError(f"{shp_path.name} is missing Gi_Bin or district")

        binary_col = f"{abbr}_{year}"
        gi_col = f"Gi_Bin_{abbr}_{year}"
        rows = []
        for record in reader.records():
            data = record.as_dict()
            district = str(data.get("district") or data.get("District")).strip()
            gi_bin = int(data["Gi_Bin"]) if data["Gi_Bin"] is not None else 0
            rows.append({
                "District": district,
                binary_col: 1 if gi_bin > 0 else 0,
                gi_col: gi_bin,
            })

        df = pd.DataFrame(rows)
        if all_districts is None:
            all_districts = df["District"].tolist()
        elif df["District"].tolist() != all_districts:
            raise ValueError(f"District order/name mismatch in {shp_path.name}")

        layers.append({
            "path": shp_path,
            "year": year,
            "season_key": season_key,
            "season": season_label,
            "abbr": abbr,
            "season_order": season_order,
            "binary_col": binary_col,
            "gi_col": gi_col,
            "df": df,
        })

    if all_districts is None:
        raise FileNotFoundError(f"No hotspot shapefiles found in {INPUT_HOTSPOT_DIR}")

    return layers, all_districts


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    layers, all_districts = load_layers()
    layers_sorted = sorted(layers, key=lambda item: (item["year"], item["season_order"]))

    binary = pd.DataFrame({"District": all_districts})
    gi_bins = pd.DataFrame({"District": all_districts})
    metadata_rows = []

    for layer in layers_sorted:
        binary = binary.merge(layer["df"][["District", layer["binary_col"]]], on="District", how="left")
        gi_bins = gi_bins.merge(layer["df"][["District", layer["gi_col"]]], on="District", how="left")
        metadata_rows.append({
            "File": layer["path"].name,
            "Year": layer["year"],
            "Season": layer["season"],
            "Binary_column": layer["binary_col"],
            "Hotspot_rule": "1 if Gi_Bin > 0, else 0",
            "District_count": len(all_districts),
            "Hotspot_count": int(layer["df"][layer["binary_col"]].sum()),
        })

    metadata = pd.DataFrame(metadata_rows)
    jaccard_rows = []
    for season_label in ["Winter", "Pre-monsoon", "Monsoon", "Post-monsoon"]:
        season_layers = sorted(
            [layer for layer in layers if layer["season"] == season_label],
            key=lambda item: item["year"],
        )
        for first, second in zip(season_layers, season_layers[1:]):
            s1 = binary[first["binary_col"]].astype(int)
            s2 = binary[second["binary_col"]].astype(int)
            shared = int(((s1 == 1) & (s2 == 1)).sum())
            either = int(((s1 == 1) | (s2 == 1)).sum())
            jaccard_rows.append({
                "Season": season_label,
                "Year_1": first["year"],
                "Year_2": second["year"],
                "Comparison": f"{first['abbr']}_{first['year']} vs {second['abbr']}_{second['year']}",
                "Shared_hotspots_both_1": shared,
                "Either_hotspot_at_least_one_1": either,
                "Hotspot_only_year_1": int(((s1 == 1) & (s2 == 0)).sum()),
                "Hotspot_only_year_2": int(((s1 == 0) & (s2 == 1)).sum()),
                "Neither_hotspot_both_0": int(((s1 == 0) & (s2 == 0)).sum()),
                "Districts_total": len(all_districts),
                "Jaccard_score": shared / either if either else 1.0,
            })

    jaccard = pd.DataFrame(jaccard_rows)
    jaccard_common = jaccard[(jaccard["Year_1"] >= 2020) & (jaccard["Year_2"] <= 2024)].copy()

    hotspot_counts = pd.DataFrame([{
        "Year": layer["year"],
        "Season": layer["season"],
        "Season_order": layer["season_order"],
        "Column": layer["binary_col"],
        "Hotspot_count": int(binary[layer["binary_col"]].sum()),
        "Not_hotspot_count": int((binary[layer["binary_col"]] == 0).sum()),
        "Hotspot_percent": float(binary[layer["binary_col"]].mean() * 100),
    } for layer in layers_sorted])

    binary_cols = [layer["binary_col"] for layer in layers_sorted]
    district_frequency = binary[["District"]].copy()
    district_frequency["Hotspot_frequency_all_layers"] = binary[binary_cols].sum(axis=1)
    district_frequency["Hotspot_percent_all_layers"] = (
        district_frequency["Hotspot_frequency_all_layers"] / len(binary_cols) * 100
    )
    for season_label in ["Winter", "Pre-monsoon", "Monsoon", "Post-monsoon"]:
        cols = [layer["binary_col"] for layer in layers_sorted if layer["season"] == season_label]
        if cols:
            key = season_label.replace("-", "").replace(" ", "_")
            district_frequency[f"{key}_frequency"] = binary[cols].sum(axis=1)
            district_frequency[f"{key}_years_available"] = len(cols)
    district_frequency = district_frequency.sort_values(
        ["Hotspot_frequency_all_layers", "District"],
        ascending=[False, True],
    )

    binary.to_csv(OUTPUT_DIR / "binary_hotspot_matrix.csv", index=False)
    gi_bins.to_csv(OUTPUT_DIR / "gi_bin_matrix.csv", index=False)
    jaccard.to_csv(OUTPUT_DIR / "jaccard_same_season_consecutive_years.csv", index=False)
    jaccard_common.to_csv(OUTPUT_DIR / "jaccard_same_season_2020_2024_common.csv", index=False)
    hotspot_counts.to_csv(OUTPUT_DIR / "hotspot_counts_by_season_year.csv", index=False)
    district_frequency.to_csv(OUTPUT_DIR / "district_hotspot_frequency.csv", index=False)
    metadata.to_csv(OUTPUT_DIR / "input_layer_metadata.csv", index=False)

    with pd.ExcelWriter(OUTPUT_DIR / "Jaccard_Similarity_Index_outputs.xlsx", engine="openpyxl") as writer:
        binary.to_excel(writer, sheet_name="Binary_matrix", index=False)
        gi_bins.to_excel(writer, sheet_name="Gi_Bin_matrix", index=False)
        jaccard.to_excel(writer, sheet_name="Jaccard_all_available", index=False)
        jaccard_common.to_excel(writer, sheet_name="Jaccard_2020_2024", index=False)
        hotspot_counts.to_excel(writer, sheet_name="Hotspot_counts", index=False)
        district_frequency.to_excel(writer, sheet_name="District_frequency", index=False)
        metadata.to_excel(writer, sheet_name="Input_metadata", index=False)

    sns.set_theme(style="whitegrid", font_scale=1.0)

    plt.figure(figsize=(10, 6), dpi=200)
    for season, season_df in jaccard.groupby("Season", sort=False):
        season_df = season_df.sort_values("Year_2")
        x_labels = [f"{int(row.Year_1)}-{int(row.Year_2)}" for row in season_df.itertuples()]
        plt.plot(x_labels, season_df["Jaccard_score"], marker="o", linewidth=2.2, label=season)
    plt.ylim(0, 1.02)
    plt.xlabel("Consecutive year comparison")
    plt.ylabel("Jaccard Similarity Index")
    plt.title("Same-season hotspot similarity across consecutive years")
    plt.legend(title="Season", frameon=True)
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "jaccard_same_season_line_plot.png")
    plt.close()

    heat = jaccard.pivot(index="Season", columns="Comparison", values="Jaccard_score")
    heat = heat.reindex(["Winter", "Pre-monsoon", "Monsoon", "Post-monsoon"])
    plt.figure(figsize=(13, 4.8), dpi=200)
    sns.heatmap(
        heat,
        annot=True,
        fmt=".2f",
        cmap="YlGnBu",
        vmin=0,
        vmax=1,
        linewidths=0.5,
        cbar_kws={"label": "Jaccard score"},
    )
    plt.xlabel("Comparison")
    plt.ylabel("Season")
    plt.title("Jaccard similarity by same-season consecutive-year comparison")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "jaccard_same_season_heatmap.png")
    plt.close()

    binary_plot = binary.set_index("District")[binary_cols]
    plt.figure(figsize=(12, 15), dpi=200)
    sns.heatmap(
        binary_plot,
        cmap=sns.color_palette(["#f2f2f2", "#c0392b"]),
        linewidths=0.15,
        linecolor="#d9d9d9",
        cbar_kws={"ticks": [0.25, 0.75], "label": "Hotspot status"},
    )
    plt.title("Binary hotspot matrix by district and season-year")
    plt.xlabel("Season-year")
    plt.ylabel("District")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "binary_hotspot_matrix_heatmap.png")
    plt.close()

    plt.figure(figsize=(11, 6), dpi=200)
    for season, season_df in hotspot_counts.groupby("Season", sort=False):
        season_df = season_df.sort_values("Year")
        plt.plot(season_df["Year"], season_df["Hotspot_count"], marker="o", linewidth=2.2, label=season)
    plt.xticks(sorted(hotspot_counts["Year"].unique()))
    plt.ylabel("Number of hotspot districts")
    plt.xlabel("Year")
    plt.title("Hotspot district counts by season and year")
    plt.legend(title="Season")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "hotspot_counts_by_season_year.png")
    plt.close()

    top = district_frequency.head(20).sort_values("Hotspot_frequency_all_layers")
    plt.figure(figsize=(9, 7), dpi=200)
    plt.barh(top["District"], top["Hotspot_frequency_all_layers"], color="#2f6f8f")
    plt.xlabel(f"Hotspot frequency across {len(binary_cols)} season-year layers")
    plt.title("Districts with highest hotspot frequency")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "top_district_hotspot_frequency.png")
    plt.close()

    print(f"Created outputs in: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
