Jaccard Similarity Index outputs

Districts: 64
Hotspot layers: 21

Binary hotspot definition:
A district was coded as 1 (hotspot) when Gi_Bin > 0 and 0 otherwise. Positive Gi_Bin values represent statistically significant hot spots in ArcGIS Hot Spot Analysis.

Same-season comparisons:
Winter, Pre-monsoon, and Monsoon are available for 2020-2024, giving 4 consecutive-year comparisons per season. Post-monsoon is available for 2019-2024, giving 5 comparisons.

Formula:
Jaccard = shared hotspot districts in both years / hotspot districts in either year
        = count(A=1 and B=1) / count(A=1 or B=1)
