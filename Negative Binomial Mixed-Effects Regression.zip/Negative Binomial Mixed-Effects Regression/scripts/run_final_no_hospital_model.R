library(glmmTMB)
library(dplyr)
library(car)
library(ggplot2)

input_dir <- "3_csv"
output_dir <- file.path("nzj_model_output", "new_output")
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

dengue <- read.csv(file.path(input_dir, "dengue_cases.csv")) %>%
  select(district, year, month, dengue_cases, population)
climate <- read.csv(file.path(input_dir, "climate.csv")) %>%
  select(district, year, month, temperature, precipitation)
static <- read.csv(file.path(input_dir, "static_vars.csv")) %>%
  select(district, district_name, road_dist, water_dist, elev_m, female_lit, NDBI, pop_density) %>%
  rename(
    dist_water = water_dist,
    dist_roads = road_dist,
    fem_literacy = female_lit
  )

df <- dengue %>%
  left_join(climate, by = c("district", "year", "month")) %>%
  left_join(static, by = "district") %>%
  arrange(district, year, month) %>%
  mutate(
    season = case_when(
      month %in% c(12, 1, 2) ~ "winter",
      month %in% c(3, 4, 5) ~ "pre_monsoon",
      month %in% c(6, 7, 8) ~ "monsoon",
      TRUE ~ "post_monsoon"
    ),
    season = factor(season, levels = c("winter", "pre_monsoon", "monsoon", "post_monsoon")),
    district = factor(district)
  ) %>%
  group_by(district) %>%
  mutate(
    t = row_number(),
    temp_lag1 = lag(temperature),
    prec_lag1 = lag(precipitation),
    covid = as.integer(year %in% c(2020, 2021))
  ) %>%
  ungroup() %>%
  filter(!is.na(temp_lag1), !is.na(prec_lag1))

scale_vars <- c(
  "temp_lag1", "prec_lag1", "NDBI", "elev_m",
  "dist_water", "dist_roads", "fem_literacy", "pop_density"
)
for (v in scale_vars) {
  df[[paste0(v, "_z")]] <- as.numeric(scale(df[[v]]))
}

write.csv(df, file.path(output_dir, "final_model_dataset_after_lag.csv"), row.names = FALSE)

input_checks <- data.frame(
  rows_after_lag = nrow(df),
  districts = length(unique(df$district)),
  first_year = min(df$year),
  first_month_for_first_year = min(df$month[df$year == min(df$year)]),
  last_year = max(df$year),
  last_month_for_last_year = max(df$month[df$year == max(df$year)]),
  missing_values_total = sum(is.na(df)),
  negative_dengue_cases = sum(df$dengue_cases < 0),
  dengue_mean = mean(df$dengue_cases),
  dengue_variance = var(df$dengue_cases),
  dengue_variance_to_mean = var(df$dengue_cases) / mean(df$dengue_cases)
)
write.csv(input_checks, file.path(output_dir, "final_model_input_checks.csv"), row.names = FALSE)

model_formula <- dengue_cases ~
  season + t + temp_lag1_z + prec_lag1_z + covid +
  NDBI_z + elev_m_z + dist_water_z + dist_roads_z +
  fem_literacy_z + pop_density_z +
  offset(log(population)) + (1 | district)

vif_formula <- dengue_cases ~
  season + t + temp_lag1_z + prec_lag1_z + covid +
  NDBI_z + elev_m_z + dist_water_z + dist_roads_z +
  fem_literacy_z + pop_density_z

m_poisson <- glmmTMB(model_formula, family = poisson, data = df)
m_nb <- glmmTMB(model_formula, family = nbinom2, data = df)
m_zi <- glmmTMB(model_formula, ziformula = ~1, family = nbinom2, data = df)

capture.output(summary(m_nb), file = file.path(output_dir, "final_negative_binomial_model_summary.txt"))
capture.output(summary(m_poisson), file = file.path(output_dir, "final_poisson_model_summary.txt"))
capture.output(VarCorr(m_nb), file = file.path(output_dir, "final_random_effect_variance.txt"))
capture.output(vif(lm(vif_formula, data = df)), file = file.path(output_dir, "final_model_vif.txt"))

vif_out <- as.data.frame(vif(lm(vif_formula, data = df)))
vif_out$variable <- rownames(vif_out)
rownames(vif_out) <- NULL
write.csv(vif_out, file.path(output_dir, "final_model_vif.csv"), row.names = FALSE)

model_comparison <- AIC(m_poisson, m_nb, m_zi)
write.csv(model_comparison, file.path(output_dir, "final_model_comparison_poisson_nb_zinb.csv"))

coefs <- summary(m_nb)$coefficients$cond
irr <- data.frame(
  variable = rownames(coefs),
  coef_log = coefs[, "Estimate"],
  std_error = coefs[, "Std. Error"],
  z_value = coefs[, "z value"],
  p_value = coefs[, "Pr(>|z|)"],
  row.names = NULL
)
irr$CI_lower_log <- irr$coef_log - 1.96 * irr$std_error
irr$CI_upper_log <- irr$coef_log + 1.96 * irr$std_error
irr$IRR <- exp(irr$coef_log)
irr$CI_lower_IRR <- exp(irr$CI_lower_log)
irr$CI_upper_IRR <- exp(irr$CI_upper_log)
write.csv(irr, file.path(output_dir, "final_negative_binomial_irr_results.csv"), row.names = FALSE)

nice_labels <- c(
  "(Intercept)" = "Intercept",
  "seasonpre_monsoon" = "Season: pre-monsoon vs winter",
  "seasonmonsoon" = "Season: monsoon vs winter",
  "seasonpost_monsoon" = "Season: post-monsoon vs winter",
  "t" = "Time trend",
  "temp_lag1_z" = "Previous-month temperature (z)",
  "prec_lag1_z" = "Previous-month precipitation (z)",
  "covid" = "COVID period (2020-2021)",
  "NDBI_z" = "NDBI (z)",
  "elev_m_z" = "Elevation (z)",
  "dist_water_z" = "Distance to water (z)",
  "dist_roads_z" = "Distance to road (z)",
  "fem_literacy_z" = "Female literacy (z)",
  "pop_density_z" = "Population density (z)"
)

publication_table <- irr %>%
  filter(variable != "(Intercept)") %>%
  mutate(
    variable_label = ifelse(variable %in% names(nice_labels), nice_labels[variable], variable),
    IRR_round = round(IRR, 3),
    CI_lower_round = round(CI_lower_IRR, 3),
    CI_upper_round = round(CI_upper_IRR, 3),
    p_value_round = signif(p_value, 3),
    IRR_95CI = paste0(IRR_round, " (", CI_lower_round, "-", CI_upper_round, ")")
  ) %>%
  select(variable, variable_label, IRR_round, CI_lower_round, CI_upper_round, IRR_95CI, p_value_round)
write.csv(publication_table, file.path(output_dir, "publication_final_model_irr_table.csv"), row.names = FALSE)

pred_cond <- predict(m_nb, type = "response")
pred_marg <- predict(m_nb, type = "response", re.form = NA)
pred_out <- df[, c("district", "year", "month", "dengue_cases", "population")]
pred_out$predicted_cases_conditional <- pred_cond
pred_out$predicted_cases_marginal <- pred_marg
pred_out$raw_residual_conditional <- df$dengue_cases - pred_cond
pred_out$pearson_residual_conditional <- residuals(m_nb, type = "pearson")
pred_out$observed_rate_per_100k <- (pred_out$dengue_cases / pred_out$population) * 100000
pred_out$predicted_conditional_rate_per_100k <- (pred_out$predicted_cases_conditional / pred_out$population) * 100000
pred_out$predicted_marginal_rate_per_100k <- (pred_out$predicted_cases_marginal / pred_out$population) * 100000
pred_out$observed_cases_log1p <- log1p(pred_out$dengue_cases)
pred_out$predicted_cases_conditional_log1p <- log1p(pred_out$predicted_cases_conditional)
write.csv(pred_out, file.path(output_dir, "final_model_predictions_residuals.csv"), row.names = FALSE)

prediction_extremes <- pred_out %>%
  mutate(
    abs_raw_residual_conditional = abs(raw_residual_conditional),
    prediction_ratio_conditional = ifelse(dengue_cases > 0, predicted_cases_conditional / dengue_cases, NA_real_)
  ) %>%
  arrange(desc(abs_raw_residual_conditional)) %>%
  select(
    district, year, month, dengue_cases, population,
    predicted_cases_conditional, predicted_cases_marginal,
    raw_residual_conditional, pearson_residual_conditional,
    observed_rate_per_100k, predicted_conditional_rate_per_100k,
    prediction_ratio_conditional
  ) %>%
  head(25)
write.csv(prediction_extremes, file.path(output_dir, "final_model_prediction_extreme_rows.csv"), row.names = FALSE)

prediction_diagnostics <- data.frame(
  metric = c(
    "observed_mean",
    "conditional_predicted_mean",
    "marginal_predicted_mean",
    "observed_total",
    "conditional_predicted_total",
    "marginal_predicted_total",
    "conditional_predicted_to_observed_total_ratio",
    "marginal_predicted_to_observed_total_ratio",
    "observed_median",
    "conditional_predicted_median",
    "marginal_predicted_median",
    "observed_p95",
    "conditional_predicted_p95",
    "marginal_predicted_p95",
    "conditional_correlation",
    "marginal_correlation",
    "conditional_mae",
    "conditional_rmse",
    "conditional_max_predicted",
    "marginal_max_predicted",
    "abs_pearson_residual_gt_3",
    "diagnostic_flag"
  ),
  value = c(
    mean(df$dengue_cases),
    mean(pred_cond),
    mean(pred_marg),
    sum(df$dengue_cases),
    sum(pred_cond),
    sum(pred_marg),
    sum(pred_cond) / sum(df$dengue_cases),
    sum(pred_marg) / sum(df$dengue_cases),
    median(df$dengue_cases),
    median(pred_cond),
    median(pred_marg),
    as.numeric(quantile(df$dengue_cases, 0.95)),
    as.numeric(quantile(pred_cond, 0.95)),
    as.numeric(quantile(pred_marg, 0.95)),
    cor(df$dengue_cases, pred_cond),
    cor(df$dengue_cases, pred_marg),
    mean(abs(df$dengue_cases - pred_cond)),
    sqrt(mean((df$dengue_cases - pred_cond)^2)),
    max(pred_cond),
    max(pred_marg),
    sum(abs(pred_out$pearson_residual_conditional) > 3),
    ifelse(sum(pred_cond) / sum(df$dengue_cases) > 2,
           "conditional_predictions_overestimate_observed_total_by_more_than_2x",
           "conditional_predictions_not_flagged_by_total_ratio")
  )
)
write.csv(prediction_diagnostics, file.path(output_dir, "final_model_prediction_diagnostics.csv"), row.names = FALSE)

plot_data <- irr %>%
  filter(variable != "(Intercept)") %>%
  mutate(variable = ifelse(variable %in% names(nice_labels), nice_labels[variable], variable))

p1 <- ggplot(plot_data, aes(x = IRR, y = reorder(variable, IRR))) +
  geom_vline(xintercept = 1, linetype = "dashed", color = "gray45") +
  geom_point(size = 2.5) +
  geom_errorbarh(aes(xmin = CI_lower_IRR, xmax = CI_upper_IRR), height = 0.2) +
  scale_x_log10() +
  labs(x = "Incidence rate ratio (log scale)", y = NULL, title = "Final Negative Binomial Model") +
  theme_minimal(base_size = 11)
ggsave(file.path(output_dir, "publication_final_model_irr_forest_plot.png"), p1, width = 8, height = 5, dpi = 300)

p2 <- ggplot(pred_out, aes(x = predicted_cases_conditional_log1p, y = pearson_residual_conditional)) +
  geom_point(alpha = 0.45, size = 0.9) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "gray45") +
  labs(x = "log(1 + predicted cases)", y = "Pearson residual", title = "Residuals vs Fitted") +
  theme_minimal(base_size = 11)
ggsave(file.path(output_dir, "final_model_residuals_vs_fitted.png"), p2, width = 7, height = 5, dpi = 300)

p3 <- ggplot(pred_out, aes(x = observed_cases_log1p, y = predicted_cases_conditional_log1p)) +
  geom_point(alpha = 0.45, size = 0.9) +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "gray45") +
  labs(x = "log(1 + observed cases)", y = "log(1 + predicted cases)", title = "Observed vs Predicted") +
  theme_minimal(base_size = 11)
ggsave(file.path(output_dir, "final_model_observed_vs_predicted.png"), p3, width = 7, height = 5, dpi = 300)

source_files <- data.frame(
  source_file = c(
    normalizePath(file.path(input_dir, "static_vars.csv")),
    normalizePath(file.path(input_dir, "climate.csv")),
    normalizePath(file.path(input_dir, "dengue_cases.csv"))
  )
)
write.csv(source_files, file.path(output_dir, "final_model_source_files.csv"), row.names = FALSE)

summary_lines <- c(
  "Final best model output",
  "",
  "Model: negative binomial mixed-effects model excluding hospital distance.",
  "Reason: sensitivity models showed hospital distance and road distance were highly correlated, and the no-hospital model had the lowest AIC.",
  "",
  paste0("Rows after lag: ", nrow(df)),
  paste0("Districts: ", length(unique(df$district))),
  paste0("AIC, negative binomial: ", round(AIC(m_nb), 3)),
  paste0("AIC, zero-inflated negative binomial: ", round(AIC(m_zi), 3)),
  paste0("AIC, Poisson: ", round(AIC(m_poisson), 3)),
  "",
  "Use publication_final_model_irr_table.csv as the main manuscript coefficient table.",
  "The intercept is excluded from the manuscript-facing IRR table.",
  "Review final_model_prediction_diagnostics.csv and final_model_prediction_extreme_rows.csv before submission."
)
writeLines(summary_lines, file.path(output_dir, "README_final_model_outputs.txt"))

cat("Final no-hospital model complete\n")
cat("Output folder:", normalizePath(output_dir), "\n")
