from pathlib import Path

import pandas as pd
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt


BASE = Path(r"D:\My Documents\_Antigravity")
OUT = BASE / "nzj_model_output" / "new_output"
DOCX = OUT / "final_model_manuscript_writeup.docx"


def fmt_p(value):
    try:
        value = float(value)
    except Exception:
        return str(value)
    if value < 0.001:
        return "<0.001"
    return f"{value:.3f}"


def add_heading(doc, text, level=1):
    doc.add_heading(text, level=level)


def add_table_from_df(doc, df, columns, headers=None):
    headers = headers or columns
    table = doc.add_table(rows=1, cols=len(columns))
    table.style = "Table Grid"
    hdr = table.rows[0].cells
    for i, header in enumerate(headers):
        hdr[i].text = header
    for _, row in df.iterrows():
        cells = table.add_row().cells
        for i, col in enumerate(columns):
            cells[i].text = "" if pd.isna(row[col]) else str(row[col])
    doc.add_paragraph()
    return table


def add_note(doc, text):
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.italic = True
    run.font.size = Pt(9)


def add_interpretation(doc, title, text):
    p = doc.add_paragraph()
    run = p.add_run(title)
    run.bold = True
    doc.add_paragraph(text)


def main():
    irr = pd.read_csv(OUT / "publication_final_model_irr_table.csv")
    comp = pd.read_csv(OUT / "final_model_comparison_poisson_nb_zinb.csv")
    checks = pd.read_csv(OUT / "final_model_input_checks.csv")
    pred = pd.read_csv(OUT / "final_model_prediction_diagnostics.csv")
    vif = pd.read_csv(OUT / "final_model_vif.csv")

    checks_row = checks.iloc[0].to_dict()
    pred_map = dict(zip(pred["metric"], pred["value"]))

    # Make model comparison easier to read.
    model_name_map = {
        "m_poisson": "Poisson",
        "m_nb": "Negative binomial",
        "m_zi": "Zero-inflated negative binomial",
    }
    first_col = comp.columns[0]
    comp["Model"] = comp[first_col].map(model_name_map).fillna(comp[first_col])
    comp["AIC"] = comp["AIC"].astype(float).round(2)
    comp["df"] = comp["df"].astype(int)

    irr["p_value_round"] = irr["p_value_round"].apply(fmt_p)
    irr["IRR_round"] = irr["IRR_round"].apply(lambda x: f"{float(x):.3f}")
    irr["CI_lower_round"] = irr["CI_lower_round"].apply(lambda x: f"{float(x):.3f}")
    irr["CI_upper_round"] = irr["CI_upper_round"].apply(lambda x: f"{float(x):.3f}")

    manuscript_vars = [
        "seasonpre_monsoon",
        "seasonmonsoon",
        "seasonpost_monsoon",
        "t",
        "temp_lag1_z",
        "prec_lag1_z",
        "covid",
        "NDBI_z",
        "elev_m_z",
        "dist_water_z",
        "dist_roads_z",
        "fem_literacy_z",
        "pop_density_z",
    ]
    irr_main = irr[irr["variable"].isin(manuscript_vars)].copy()

    doc = Document()
    styles = doc.styles
    styles["Normal"].font.name = "Arial"
    styles["Normal"].font.size = Pt(10)

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("Final Dengue-Climate Model Results")
    run.bold = True
    run.font.size = Pt(16)

    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle.add_run("Negative binomial mixed-effects model excluding hospital distance").italic = True

    add_heading(doc, "Analysis Overview", 1)
    doc.add_paragraph(
        "This analysis estimated monthly dengue case counts across 64 Bangladesh districts "
        "from July 2019 to December 2024 using a negative binomial mixed-effects model. "
        "Because the climate predictors were lagged by one month, the modeled dataset begins "
        "in August 2019 and includes 4,160 district-month observations."
    )
    doc.add_paragraph(
        "The final model excludes hospital distance because sensitivity analyses showed that "
        "hospital distance and road distance were highly correlated. The model excluding hospital "
        "distance had the lowest AIC and retained stable climate-effect estimates."
    )

    add_heading(doc, "Methods Text For Manuscript", 1)
    doc.add_paragraph(
        "Monthly dengue cases were modeled using a negative binomial mixed-effects regression "
        "to account for overdispersion in the count outcome. District population was included as "
        "an offset term using the natural logarithm of population, allowing model estimates to be "
        "interpreted as incidence rate ratios. A random intercept for district was included to "
        "account for unobserved, time-invariant differences among districts."
    )
    doc.add_paragraph(
        "The main predictors were one-month lagged temperature and one-month lagged precipitation. "
        "Both climate variables and continuous district-level covariates were standardized before "
        "model fitting. The model adjusted for season, linear time trend, COVID period, NDBI, "
        "elevation, distance to water, distance to roads, female literacy, and population density. Seasons "
        "were classified as winter (December-February), pre-monsoon (March-May), monsoon "
        "(June-August), and post-monsoon (September-November), with winter as the reference category."
    )
    doc.add_paragraph(
        "Sensitivity analyses were performed because hospital distance and road distance were highly "
        "correlated. Models excluding each predictor separately were compared using AIC, and the "
        "model excluding hospital distance was selected as the final model."
    )

    add_heading(doc, "Results Text For Manuscript", 1)
    doc.add_paragraph(
        f"The final lagged dataset included {int(checks_row['rows_after_lag'])} observations from "
        f"{int(checks_row['districts'])} districts. There were no missing values in the final model "
        "dataset and no negative dengue case counts. Dengue counts were highly overdispersed, with "
        f"a variance-to-mean ratio of {float(checks_row['dengue_variance_to_mean']):.1f}, supporting "
        "the use of a negative binomial model."
    )
    doc.add_paragraph(
        "The negative binomial model provided a substantially better fit than the Poisson model and "
        "also slightly outperformed the zero-inflated negative binomial model. Therefore, the final "
        "reported model was the negative binomial mixed-effects model excluding hospital distance."
    )
    doc.add_paragraph(
        "Previous-month temperature was strongly and positively associated with dengue incidence. "
        "A one-standard-deviation increase in lagged temperature was associated with approximately "
        "4.17 times higher dengue incidence. Previous-month precipitation was also positively "
        "associated with dengue incidence, with a one-standard-deviation increase corresponding to "
        "approximately 1.62 times higher incidence. Population density was positively associated "
        "with dengue incidence, while the COVID period was associated with substantially lower "
        "reported dengue incidence."
    )

    add_heading(doc, "Interpretation", 1)
    doc.add_paragraph(
        "The findings suggest that warmer conditions and greater rainfall in the previous month are "
        "important predictors of subsequent dengue burden at the district-month scale. The positive "
        "association with population density is consistent with higher transmission potential in "
        "more densely populated areas. The strong negative COVID-period coefficient should be "
        "interpreted cautiously because it may reflect surveillance disruption, healthcare-seeking "
        "changes, mobility changes, or a combination of true and reporting-related effects."
    )

    add_heading(doc, "Table 1. Final Model IRRs", 1)
    add_table_from_df(
        doc,
        irr_main,
        ["variable_label", "IRR_round", "CI_lower_round", "CI_upper_round", "p_value_round"],
        ["Variable", "IRR", "95% CI lower", "95% CI upper", "p-value"],
    )
    add_note(
        doc,
        "IRR = incidence rate ratio. Continuous predictors are standardized; climate variables are lagged by one month. "
        "Winter is the reference season."
    )
    add_interpretation(
        doc,
        "Interpretation of Table 1.",
        "Each IRR compares dengue incidence while holding all other variables in the model constant. Values above 1 "
        "indicate higher dengue incidence, and values below 1 indicate lower dengue incidence. For seasonal variables, "
        "winter is the reference category. For standardized continuous variables, the IRR represents the expected "
        "change in dengue incidence for a one-standard-deviation increase in that predictor."
    )
    variable_interpretations = [
        (
            "Season: pre-monsoon vs winter",
            "The IRR of 0.004 indicates that dengue incidence during the pre-monsoon season was much lower than in "
            "winter after adjustment for climate, population, district effects, COVID period, and other covariates. "
            "This association was statistically significant (p < 0.001)."
        ),
        (
            "Season: monsoon vs winter",
            "The IRR of 0.527 indicates that dengue incidence during monsoon was about 47.3% lower than in winter, "
            "holding other model variables constant. This association was statistically significant (p = 0.002)."
        ),
        (
            "Season: post-monsoon vs winter",
            "The IRR of 1.319 suggests that post-monsoon dengue incidence was about 31.9% higher than winter, but "
            "the confidence interval included 1 and the p-value was not statistically significant (p = 0.139). "
            "Therefore, this model does not provide strong evidence of a post-monsoon increase after adjustment."
        ),
        (
            "Time trend",
            "The IRR of 1.001 suggests almost no average linear month-to-month change in dengue incidence after "
            "accounting for season, climate, COVID period, district characteristics, and population. This trend was "
            "not statistically significant (p = 0.748)."
        ),
        (
            "Previous-month temperature",
            "The IRR of 4.168 indicates that a one-standard-deviation increase in previous-month temperature was "
            "associated with 4.168 times higher dengue incidence. This was one of the strongest predictors in the "
            "model and was highly statistically significant (p < 0.001)."
        ),
        (
            "Previous-month precipitation",
            "The IRR of 1.621 indicates that a one-standard-deviation increase in previous-month precipitation was "
            "associated with 62.1% higher dengue incidence. This positive association was highly statistically "
            "significant (p < 0.001)."
        ),
        (
            "COVID period (2020-2021)",
            "The IRR of 0.030 indicates that reported dengue incidence during 2020-2021 was approximately 97% lower "
            "than in non-COVID years, after adjustment for other predictors. This strong association should be "
            "interpreted cautiously because it may reflect surveillance disruption, reduced healthcare seeking, "
            "mobility restrictions, true transmission changes, or a combination of these factors."
        ),
        (
            "NDBI",
            "The IRR of 0.620 indicates that a one-standard-deviation increase in NDBI was associated with lower "
            "dengue incidence. This association was statistically significant (p = 0.012). Because NDBI represents "
            "built-up surface characteristics, this finding should be interpreted in relation to how NDBI was derived "
            "and how it varies across districts."
        ),
        (
            "Elevation",
            "The IRR of 1.271 suggests that higher elevation was associated with higher dengue incidence, but the "
            "confidence interval included 1 and the association was not statistically significant (p = 0.264). "
            "Therefore, this model does not provide strong evidence that elevation independently predicts dengue "
            "incidence after adjustment for climate, season, population density, and other covariates."
        ),
        (
            "Distance to water",
            "The IRR of 0.838 suggests a weak negative association between distance to water and dengue incidence, "
            "but the confidence interval included 1 and the association was not statistically significant (p = 0.355). "
            "There is no strong evidence from this model that distance to water independently predicts dengue incidence."
        ),
        (
            "Distance to road",
            "The IRR of 0.814 suggests a weak negative association between distance to roads and dengue incidence, "
            "but this association was not statistically significant (p = 0.279). Road distance was retained in the "
            "final model because the sensitivity analysis favored excluding hospital distance rather than road distance."
        ),
        (
            "Female literacy",
            "The IRR of 1.310 suggests that districts with higher female literacy had higher dengue incidence, but the "
            "confidence interval included 1 and the association was not statistically significant (p = 0.145). This "
            "result should not be interpreted as strong evidence of an independent literacy effect."
        ),
        (
            "Population density",
            "The IRR of 1.773 indicates that a one-standard-deviation increase in population density was associated "
            "with 77.3% higher dengue incidence. This association was statistically significant (p = 0.001), consistent "
            "with higher transmission potential in more densely populated districts."
        ),
    ]
    for label, text in variable_interpretations:
        p = doc.add_paragraph(style="List Bullet")
        p.add_run(f"{label}: ").bold = True
        p.add_run(text)

    add_heading(doc, "Table 2. Model Comparison", 1)
    add_table_from_df(doc, comp, ["Model", "df", "AIC"], ["Model", "df", "AIC"])
    add_note(doc, "Lower AIC indicates better model fit.")
    add_interpretation(
        doc,
        "Interpretation of Table 2.",
        "The negative binomial model had a much lower AIC than the Poisson model, confirming that the dengue count "
        "data were highly overdispersed and that a Poisson model was not appropriate. The zero-inflated negative "
        "binomial model did not improve fit compared with the standard negative binomial model. Therefore, the final "
        "negative binomial mixed-effects model was selected as the main publication model."
    )

    add_heading(doc, "Table 3. Final Model Diagnostics", 1)
    diagnostics = pd.DataFrame(
        {
            "Metric": [
                "Observed mean cases",
                "Conditional predicted mean",
                "Marginal predicted mean",
                "Conditional predicted / observed total",
                "Marginal predicted / observed total",
                "Conditional observed-predicted correlation",
                "Marginal observed-predicted correlation",
                "Conditional MAE",
                "Absolute Pearson residuals > 3",
                "Diagnostic flag",
            ],
            "Value": [
                f"{float(pred_map['observed_mean']):.2f}",
                f"{float(pred_map['conditional_predicted_mean']):.2f}",
                f"{float(pred_map['marginal_predicted_mean']):.2f}",
                f"{float(pred_map['conditional_predicted_to_observed_total_ratio']):.2f}",
                f"{float(pred_map['marginal_predicted_to_observed_total_ratio']):.2f}",
                f"{float(pred_map['conditional_correlation']):.3f}",
                f"{float(pred_map['marginal_correlation']):.3f}",
                f"{float(pred_map['conditional_mae']):.2f}",
                f"{int(float(pred_map['abs_pearson_residual_gt_3']))}",
                str(pred_map.get("diagnostic_flag", "")),
            ],
        }
    )
    add_table_from_df(doc, diagnostics, ["Metric", "Value"])
    add_interpretation(
        doc,
        "Interpretation of Table 3.",
        "The diagnostic summary indicates that the model captured the broad dengue pattern reasonably well, with an "
        "observed-predicted correlation of about 0.71. However, conditional fitted totals are substantially higher "
        "than observed totals, so the prediction diagnostics should be interpreted as a calibration warning rather "
        "than as publication evidence of accurate case-count prediction. The largest discrepancies are listed in "
        "final_model_prediction_extreme_rows.csv. This model is best presented for adjusted associations unless "
        "additional calibration work is completed."
    )

    add_heading(doc, "Table 4. Main Model VIF", 1)
    vif_cols = list(vif.columns)
    if "variable" in vif_cols:
        vif_display = vif.copy()
        vif_display["GVIF"] = vif_display["GVIF"].astype(float).round(3)
        vif_display["GVIF^(1/(2*Df))"] = vif_display["GVIF^(1/(2*Df))"].astype(float).round(3)
        add_table_from_df(
            doc,
            vif_display,
            ["variable", "GVIF", "Df", "GVIF^(1/(2*Df))"],
            ["Variable", "GVIF", "Df", "Adjusted GVIF"],
        )
        add_interpretation(
            doc,
            "Interpretation of Table 4.",
            "The VIF results show that multicollinearity was acceptable in the final model after excluding hospital "
            "distance. Most adjusted GVIF values were close to 1, and none suggested severe remaining collinearity. "
            "This supports the decision to remove hospital distance, which was highly correlated with road distance "
            "in the sensitivity analysis."
        )

    add_heading(doc, "Figures", 1)
    for file_name, caption in [
        ("publication_final_model_irr_forest_plot.png", "Figure 1. Final model incidence rate ratios."),
        ("final_model_residuals_vs_fitted.png", "Figure 2. Residuals versus fitted values."),
        ("final_model_observed_vs_predicted.png", "Figure 3. Observed versus predicted dengue cases on log(1 + cases) scale."),
    ]:
        path = OUT / file_name
        if path.exists():
            doc.add_picture(str(path), width=Inches(6.5))
            p = doc.add_paragraph(caption)
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER

    add_heading(doc, "Suggested Manuscript Conclusion", 1)
    doc.add_paragraph(
        "In this district-level monthly analysis, lagged temperature and precipitation were robust "
        "predictors of dengue incidence in Bangladesh from 2019 to 2024. The final negative binomial "
        "mixed-effects model indicated that warmer and wetter conditions in the preceding month were "
        "associated with higher dengue incidence, even after accounting for seasonality, population "
        "density, COVID period, district-level built-environment variables, and unobserved district "
        "heterogeneity."
    )

    add_heading(doc, "Recommended Next Steps Before Submission", 1)
    for item in [
        "Review the final IRR table and confirm variable names match the manuscript terminology.",
        "Use the model comparison table to justify negative binomial rather than Poisson or zero-inflated negative binomial.",
        "Report the sensitivity analysis showing that excluding hospital distance gave the best AIC and did not change the climate effects.",
        "Place residual and observed-versus-predicted plots in the supplementary material.",
        "Interpret the COVID-period coefficient cautiously as a reporting and disruption period rather than a purely biological effect.",
    ]:
        doc.add_paragraph(item, style="List Bullet")

    doc.save(DOCX)
    print(DOCX)


if __name__ == "__main__":
    main()
